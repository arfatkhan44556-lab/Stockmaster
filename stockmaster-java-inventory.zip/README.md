# StockMaster Java - Inventory Stock Management System

A production-ready Enterprise Inventory Management System built in **Java** featuring a **Graphical User Interface (GUI)** using JavaFX and **Database Connectivity (JDBC)** with support for SQLite and MySQL.

---

## 🚀 Key Features

- **Graphical User Interface (JavaFX)**: High-density interactive inventory TableView, real-time search, category filtering, low-stock visual cues, and modal dialogs.
- **Robust Database Connectivity (JDBC)**: Thread-safe HikariCP connection pool with PreparedStatement protection against SQL injection.
- **Stock Movement Ledger**: Complete audit trail for Inbound Receipts (`STOCK_IN`), Outbound Dispatches (`STOCK_OUT`), and Reconciliations (`ADJUSTMENT`).
- **Automated Reordering**: Identifies depleted items below threshold and allows one-click purchase order restock.
- **Dual Database Support**:
  - **SQLite (Default)**: Embedded, self-contained, zero-configuration local database (`stockmaster_inventory.db`).
  - **MySQL**: Enterprise client-server database configured via environment variables.

---

## 🛠 Prerequisites

- **Java JDK 21** or later (Eclipse Temurin, OpenJDK, or Oracle JDK).
- **Apache Maven 3.8+** (or use IntelliJ / Eclipse bundled Maven).

---

## ⚡ How to Run

### Option 1: Terminal with Maven (Quickest)

```bash
# 1. Clone or extract the project zip
cd stockmaster-inventory

# 2. Compile and launch the JavaFX GUI
mvn clean javafx:run
```

### Option 2: IntelliJ IDEA

1. Open IntelliJ IDEA → **File** → **Open...** → Select `pom.xml`.
2. Wait for Maven dependencies to sync.
3. Locate `src/main/java/com/stockmaster/InventoryApp.java`.
4. Right-click → **Run 'InventoryApp.main()'**.

---

## 🗄 Database Configuration

By default, the app initializes an embedded SQLite database (`stockmaster_inventory.db`) in the working directory.

To connect to a **MySQL** server instead, set the following environment variables:

```bash
export JDBC_MYSQL_URL="jdbc:mysql://localhost:3306/stockmaster_db?useSSL=false&allowPublicKeyRetrieval=true"
export JDBC_MYSQL_USER="root"
export JDBC_MYSQL_PASSWORD="your_password"
mvn javafx:run
```
