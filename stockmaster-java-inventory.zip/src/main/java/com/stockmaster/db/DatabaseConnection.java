package com.stockmaster.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Thread-safe Singleton Database Connection Provider using HikariCP.
 * Supports SQLite (default embedded) and MySQL enterprise database.
 */
public class DatabaseConnection {

    private static HikariDataSource dataSource;

    // Default configuration: SQLite local persistent database file
    private static final String DEFAULT_SQLITE_URL = "jdbc:sqlite:stockmaster_inventory.db";
    private static final String SQLITE_DRIVER = "org.sqlite.JDBC";

    private DatabaseConnection() {}

    public static synchronized Connection getConnection() throws SQLException {
        if (dataSource == null || dataSource.isClosed()) {
            initDataSource();
        }
        return dataSource.getConnection();
    }

    private static void initDataSource() {
        HikariConfig config = new HikariConfig();
        
        // Check if environment specifies MySQL
        String mysqlUrl = System.getenv("JDBC_MYSQL_URL");
        if (mysqlUrl != null && !mysqlUrl.isBlank()) {
            config.setJdbcUrl(mysqlUrl);
            config.setDriverClassName("com.mysql.cj.jdbc.Driver");
            config.setUsername(System.getenv("JDBC_MYSQL_USER"));
            config.setPassword(System.getenv("JDBC_MYSQL_PASSWORD"));
        } else {
            // Embedded SQLite Database
            config.setJdbcUrl(DEFAULT_SQLITE_URL);
            config.setDriverClassName(SQLITE_DRIVER);
        }

        // Connection Pool parameters
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        config.setIdleTimeout(30000);
        config.setConnectionTimeout(20000);
        config.setPoolName("StockMaster-HikariPool");

        dataSource = new HikariDataSource(config);
    }

    /**
     * Bootstraps schema DDL tables on first startup
     */
    public static void initializeDatabase() throws SQLException {
        String createCategoriesTable = """
            CREATE TABLE IF NOT EXISTS categories (
                category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                code VARCHAR(30) NOT NULL UNIQUE,
                name VARCHAR(100) NOT NULL,
                description TEXT
            );
        """;

        String createSuppliersTable = """
            CREATE TABLE IF NOT EXISTS suppliers (
                supplier_id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_name VARCHAR(150) NOT NULL,
                contact_person VARCHAR(100),
                email VARCHAR(120),
                phone VARCHAR(50),
                lead_time_days INTEGER DEFAULT 3,
                address TEXT
            );
        """;

        String createItemsTable = """
            CREATE TABLE IF NOT EXISTS items (
                item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku VARCHAR(50) NOT NULL UNIQUE,
                name VARCHAR(150) NOT NULL,
                category VARCHAR(100) NOT NULL,
                description TEXT,
                unit VARCHAR(20) DEFAULT 'pcs',
                quantity INTEGER NOT NULL DEFAULT 0,
                min_stock INTEGER NOT NULL DEFAULT 10,
                max_stock INTEGER NOT NULL DEFAULT 100,
                cost_price REAL NOT NULL DEFAULT 0.00,
                selling_price REAL NOT NULL DEFAULT 0.00,
                supplier_id INTEGER,
                location_bin VARCHAR(50),
                status VARCHAR(30) NOT NULL DEFAULT 'IN_STOCK',
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
            );
        """;

        String createTransactionsTable = """
            CREATE TABLE IF NOT EXISTS inventory_transactions (
                txn_id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER NOT NULL,
                item_sku VARCHAR(50) NOT NULL,
                item_name VARCHAR(150) NOT NULL,
                txn_type VARCHAR(30) NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                total_value REAL NOT NULL,
                reference_no VARCHAR(80) NOT NULL,
                reason TEXT,
                performed_by VARCHAR(80) DEFAULT 'operator',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items(item_id)
            );
        """;

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute(createCategoriesTable);
            stmt.execute(createSuppliersTable);
            stmt.execute(createItemsTable);
            stmt.execute(createTransactionsTable);
        }
    }

    public static synchronized void closePool() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
