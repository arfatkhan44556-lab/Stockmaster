package com.stockmaster.dao;

import com.stockmaster.db.DatabaseConnection;
import com.stockmaster.model.StockTransaction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAOImpl implements TransactionDAO {

    @Override
    public List<StockTransaction> getAllTransactions() throws SQLException {
        String sql = "SELECT * FROM inventory_transactions ORDER BY txn_id DESC";
        List<StockTransaction> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        }
        return list;
    }

    @Override
    public List<StockTransaction> getTransactionsByItemId(int itemId) throws SQLException {
        String sql = "SELECT * FROM inventory_transactions WHERE item_id = ? ORDER BY txn_id DESC";
        List<StockTransaction> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, itemId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        }
        return list;
    }

    @Override
    public boolean recordTransaction(StockTransaction txn) throws SQLException {
        String sql = """
            INSERT INTO inventory_transactions (item_id, item_sku, item_name, txn_type, quantity, unit_price, total_value, reference_no, reason, performed_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, txn.getItemId());
            pstmt.setString(2, txn.getItemSku());
            pstmt.setString(3, txn.getItemName());
            pstmt.setString(4, txn.getType());
            pstmt.setInt(5, txn.getQuantity());
            pstmt.setDouble(6, txn.getUnitPrice());
            pstmt.setDouble(7, txn.getTotalValue());
            pstmt.setString(8, txn.getReferenceNo());
            pstmt.setString(9, txn.getReason());
            pstmt.setString(10, txn.getPerformedBy());
            return pstmt.executeUpdate() > 0;
        }
    }

    private StockTransaction mapResultSet(ResultSet rs) throws SQLException {
        return new StockTransaction(
            rs.getInt("txn_id"),
            rs.getInt("item_id"),
            rs.getString("item_sku"),
            rs.getString("item_name"),
            rs.getString("txn_type"),
            rs.getInt("quantity"),
            rs.getDouble("unit_price"),
            rs.getDouble("total_value"),
            rs.getString("reference_no"),
            rs.getString("reason"),
            rs.getString("performed_by"),
            rs.getString("created_at")
        );
    }
}
