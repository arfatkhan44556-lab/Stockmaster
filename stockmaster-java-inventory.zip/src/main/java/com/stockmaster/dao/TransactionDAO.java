package com.stockmaster.dao;

import com.stockmaster.model.StockTransaction;
import java.sql.SQLException;
import java.util.List;

public interface TransactionDAO {
    List<StockTransaction> getAllTransactions() throws SQLException;
    List<StockTransaction> getTransactionsByItemId(int itemId) throws SQLException;
    boolean recordTransaction(StockTransaction transaction) throws SQLException;
}
