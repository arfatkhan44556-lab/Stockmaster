package com.stockmaster.dao;

import com.stockmaster.db.DatabaseConnection;
import com.stockmaster.model.Item;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ItemDAOImpl implements ItemDAO {

    @Override
    public List<Item> getAllItems() throws SQLException {
        String sql = "SELECT * FROM items ORDER BY item_id ASC";
        List<Item> items = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                items.add(mapResultSetToItem(rs));
            }
        }
        return items;
    }

    @Override
    public Optional<Item> getItemById(int id) throws SQLException {
        String sql = "SELECT * FROM items WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToItem(rs));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public Optional<Item> getItemBySku(String sku) throws SQLException {
        String sql = "SELECT * FROM items WHERE UPPER(sku) = UPPER(?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, sku);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToItem(rs));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Item> getLowStockItems() throws SQLException {
        String sql = "SELECT * FROM items WHERE quantity <= min_stock ORDER BY quantity ASC";
        List<Item> items = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                items.add(mapResultSetToItem(rs));
            }
        }
        return items;
    }

    @Override
    public List<Item> searchItems(String keyword, String category) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM items WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND (LOWER(sku) LIKE ? OR LOWER(name) LIKE ? OR LOWER(location_bin) LIKE ?)");
            String term = "%" + keyword.toLowerCase().trim() + "%";
            params.add(term);
            params.add(term);
            params.add(term);
        }

        if (category != null && !category.isBlank() && !"All Categories".equalsIgnoreCase(category)) {
            sql.append(" AND category = ?");
            params.add(category);
        }

        sql.append(" ORDER BY item_id ASC");

        List<Item> items = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    items.add(mapResultSetToItem(rs));
                }
            }
        }
        return items;
    }

    @Override
    public boolean addItem(Item item) throws SQLException {
        String sql = """
            INSERT INTO items (sku, name, category, description, unit, quantity, min_stock, max_stock, cost_price, selling_price, supplier_id, location_bin, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, item.getSku());
            pstmt.setString(2, item.getName());
            pstmt.setString(3, item.getCategory());
            pstmt.setString(4, item.getDescription());
            pstmt.setString(5, item.getUnit());
            pstmt.setInt(6, item.getQuantity());
            pstmt.setInt(7, item.getMinStock());
            pstmt.setInt(8, item.getMaxStock());
            pstmt.setDouble(9, item.getCostPrice());
            pstmt.setDouble(10, item.getSellingPrice());
            pstmt.setInt(11, item.getSupplierId());
            pstmt.setString(12, item.getLocationBin());
            pstmt.setString(13, computeStatus(item.getQuantity(), item.getMinStock(), item.getMaxStock()));

            int affected = pstmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = pstmt.getGeneratedKeys()) {
                    if (keys.next()) {
                        item.setId(keys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        }
    }

    @Override
    public boolean updateItem(Item item) throws SQLException {
        String sql = """
            UPDATE items SET sku=?, name=?, category=?, description=?, unit=?, quantity=?,
            min_stock=?, max_stock=?, cost_price=?, selling_price=?, supplier_id=?,
            location_bin=?, status=?, updated_at=CURRENT_TIMESTAMP
            WHERE item_id=?
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, item.getSku());
            pstmt.setString(2, item.getName());
            pstmt.setString(3, item.getCategory());
            pstmt.setString(4, item.getDescription());
            pstmt.setString(5, item.getUnit());
            pstmt.setInt(6, item.getQuantity());
            pstmt.setInt(7, item.getMinStock());
            pstmt.setInt(8, item.getMaxStock());
            pstmt.setDouble(9, item.getCostPrice());
            pstmt.setDouble(10, item.getSellingPrice());
            pstmt.setInt(11, item.getSupplierId());
            pstmt.setString(12, item.getLocationBin());
            pstmt.setString(13, computeStatus(item.getQuantity(), item.getMinStock(), item.getMaxStock()));
            pstmt.setInt(14, item.getId());

            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateStockQuantity(int itemId, int newQuantity) throws SQLException {
        String sql = """
            UPDATE items SET quantity=?, status=?, updated_at=CURRENT_TIMESTAMP
            WHERE item_id=?
        """;

        // Query min and max stock first to compute new status
        Optional<Item> current = getItemById(itemId);
        if (current.isEmpty()) return false;

        String status = computeStatus(newQuantity, current.get().getMinStock(), current.get().getMaxStock());

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newQuantity);
            pstmt.setString(2, status);
            pstmt.setInt(3, itemId);
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteItem(int id) throws SQLException {
        String sql = "DELETE FROM items WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public double calculateTotalInventoryValuation() throws SQLException {
        String sql = "SELECT SUM(quantity * cost_price) as total_val FROM items";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble("total_val");
            }
        }
        return 0.0;
    }

    private Item mapResultSetToItem(ResultSet rs) throws SQLException {
        Item item = new Item();
        item.setId(rs.getInt("item_id"));
        item.setSku(rs.getString("sku"));
        item.setName(rs.getString("name"));
        item.setCategory(rs.getString("category"));
        item.setDescription(rs.getString("description"));
        item.setUnit(rs.getString("unit"));
        item.setQuantity(rs.getInt("quantity"));
        item.setMinStock(rs.getInt("min_stock"));
        item.setMaxStock(rs.getInt("max_stock"));
        item.setCostPrice(rs.getDouble("cost_price"));
        item.setSellingPrice(rs.getDouble("selling_price"));
        item.setSupplierId(rs.getInt("supplier_id"));
        item.setLocationBin(rs.getString("location_bin"));
        item.setStatus(rs.getString("status"));
        item.setUpdatedAt(rs.getString("updated_at"));
        return item;
    }

    private String computeStatus(int qty, int min, int max) {
        if (qty <= 0) return "OUT_OF_STOCK";
        if (qty <= min) return "LOW_STOCK";
        if (qty >= max) return "OVERSTOCKED";
        return "IN_STOCK";
    }
}
