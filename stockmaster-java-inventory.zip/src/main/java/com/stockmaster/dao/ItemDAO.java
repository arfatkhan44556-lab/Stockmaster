package com.stockmaster.dao;

import com.stockmaster.model.Item;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface ItemDAO {
    List<Item> getAllItems() throws SQLException;
    Optional<Item> getItemById(int id) throws SQLException;
    Optional<Item> getItemBySku(String sku) throws SQLException;
    List<Item> getLowStockItems() throws SQLException;
    List<Item> searchItems(String keyword, String category) throws SQLException;
    
    boolean addItem(Item item) throws SQLException;
    boolean updateItem(Item item) throws SQLException;
    boolean updateStockQuantity(int itemId, int newQuantity) throws SQLException;
    boolean deleteItem(int id) throws SQLException;
    
    double calculateTotalInventoryValuation() throws SQLException;
}
