package com.stockmaster.model;

public class StockTransaction {
    private int id;
    private int itemId;
    private String itemSku;
    private String itemName;
    private String type;
    private int quantity;
    private double unitPrice;
    private double totalValue;
    private String referenceNo;
    private String reason;
    private String performedBy;
    private String timestamp;

    public StockTransaction() {}

    public StockTransaction(int id, int itemId, String itemSku, String itemName, String type,
                            int quantity, double unitPrice, double totalValue,
                            String referenceNo, String reason, String performedBy) {
        this(id, itemId, itemSku, itemName, type, quantity, unitPrice, totalValue, referenceNo, reason, performedBy, null);
    }

    public StockTransaction(int id, int itemId, String itemSku, String itemName, String type,
                            int quantity, double unitPrice, double totalValue,
                            String referenceNo, String reason, String performedBy, String timestamp) {
        this.id = id;
        this.itemId = itemId;
        this.itemSku = itemSku;
        this.itemName = itemName;
        this.type = type;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.totalValue = totalValue;
        this.referenceNo = referenceNo;
        this.reason = reason;
        this.performedBy = performedBy;
        this.timestamp = timestamp;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getItemId() { return itemId; }
    public void setItemId(int itemId) { this.itemId = itemId; }

    public String getItemSku() { return itemSku; }
    public void setItemSku(String itemSku) { this.itemSku = itemSku; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public double getTotalValue() { return totalValue; }
    public void setTotalValue(double totalValue) { this.totalValue = totalValue; }

    public String getReferenceNo() { return referenceNo; }
    public void setReferenceNo(String referenceNo) { this.referenceNo = referenceNo; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getPerformedBy() { return performedBy; }
    public void setPerformedBy(String performedBy) { this.performedBy = performedBy; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
