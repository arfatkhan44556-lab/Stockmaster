package com.stockmaster.model;

import javafx.beans.property.*;

public class Item {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty sku = new SimpleStringProperty();
    private final StringProperty name = new SimpleStringProperty();
    private final StringProperty category = new SimpleStringProperty();
    private final StringProperty description = new SimpleStringProperty();
    private final StringProperty unit = new SimpleStringProperty("pcs");
    private final IntegerProperty quantity = new SimpleIntegerProperty(0);
    private final IntegerProperty minStock = new SimpleIntegerProperty(10);
    private final IntegerProperty maxStock = new SimpleIntegerProperty(100);
    private final DoubleProperty costPrice = new SimpleDoubleProperty(0.0);
    private final DoubleProperty sellingPrice = new SimpleDoubleProperty(0.0);
    private final IntegerProperty supplierId = new SimpleIntegerProperty(1);
    private final StringProperty locationBin = new SimpleStringProperty("A-01-01");
    private final StringProperty status = new SimpleStringProperty("IN_STOCK");
    private final StringProperty updatedAt = new SimpleStringProperty();

    public Item() {}

    // Property getters for JavaFX TableView bindings
    public IntegerProperty idProperty() { return id; }
    public StringProperty skuProperty() { return sku; }
    public StringProperty nameProperty() { return name; }
    public StringProperty categoryProperty() { return category; }
    public StringProperty descriptionProperty() { return description; }
    public StringProperty unitProperty() { return unit; }
    public IntegerProperty quantityProperty() { return quantity; }
    public IntegerProperty minStockProperty() { return minStock; }
    public IntegerProperty maxStockProperty() { return maxStock; }
    public DoubleProperty costPriceProperty() { return costPrice; }
    public DoubleProperty sellingPriceProperty() { return sellingPrice; }
    public IntegerProperty supplierIdProperty() { return supplierId; }
    public StringProperty locationBinProperty() { return locationBin; }
    public StringProperty statusProperty() { return status; }
    public StringProperty updatedAtProperty() { return updatedAt; }

    // Standard getters & setters
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }

    public String getSku() { return sku.get(); }
    public void setSku(String sku) { this.sku.set(sku); }

    public String getName() { return name.get(); }
    public void setName(String name) { this.name.set(name); }

    public String getCategory() { return category.get(); }
    public void setCategory(String category) { this.category.set(category); }

    public String getDescription() { return description.get(); }
    public void setDescription(String description) { this.description.set(description); }

    public String getUnit() { return unit.get(); }
    public void setUnit(String unit) { this.unit.set(unit); }

    public int getQuantity() { return quantity.get(); }
    public void setQuantity(int quantity) { this.quantity.set(quantity); }

    public int getMinStock() { return minStock.get(); }
    public void setMinStock(int minStock) { this.minStock.set(minStock); }

    public int getMaxStock() { return maxStock.get(); }
    public void setMaxStock(int maxStock) { this.maxStock.set(maxStock); }

    public double getCostPrice() { return costPrice.get(); }
    public void setCostPrice(double costPrice) { this.costPrice.set(costPrice); }

    public double getSellingPrice() { return sellingPrice.get(); }
    public void setSellingPrice(double sellingPrice) { this.sellingPrice.set(sellingPrice); }

    public int getSupplierId() { return supplierId.get(); }
    public void setSupplierId(int supplierId) { this.supplierId.set(supplierId); }

    public String getLocationBin() { return locationBin.get(); }
    public void setLocationBin(String locationBin) { this.locationBin.set(locationBin); }

    public String getStatus() { return status.get(); }
    public void setStatus(String status) { this.status.set(status); }

    public String getUpdatedAt() { return updatedAt.get(); }
    public void setUpdatedAt(String updatedAt) { this.updatedAt.set(updatedAt); }
}
