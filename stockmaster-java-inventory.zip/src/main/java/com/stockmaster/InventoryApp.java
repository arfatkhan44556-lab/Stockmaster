package com.stockmaster;

import com.stockmaster.dao.ItemDAO;
import com.stockmaster.dao.ItemDAOImpl;
import com.stockmaster.dao.TransactionDAO;
import com.stockmaster.dao.TransactionDAOImpl;
import com.stockmaster.db.DatabaseConnection;
import com.stockmaster.model.Item;
import com.stockmaster.model.StockTransaction;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Optional;

/**
 * StockMaster Java - Inventory Management GUI
 * Built with JavaFX and JDBC Database Connectivity
 */
public class InventoryApp extends Application {

    private final ItemDAO itemDAO = new ItemDAOImpl();
    private final TransactionDAO transactionDAO = new TransactionDAOImpl();

    private final ObservableList<Item> masterInventoryData = FXCollections.observableArrayList();
    private FilteredList<Item> filteredData;

    private TableView<Item> tableView;
    private TextField searchField;
    private ComboBox<String> categoryComboBox;
    private CheckBox lowStockOnlyCheckBox;

    // Stat metric labels
    private Label totalItemsLabel;
    private Label totalAssetValLabel;
    private Label lowStockCountLabel;
    private Label outOfStockLabel;

    private final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.US);

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("StockMaster - Java Inventory Stock Management");

        // Initialize database tables if needed
        try {
            DatabaseConnection.initializeDatabase();
        } catch (SQLException e) {
            showError("Database Init Error", "Failed to initialize database tables: " + e.getMessage());
        }

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #0b0f19;");

        // 1. Header & Metric Statistics
        VBox topContainer = new VBox(12);
        topContainer.setPadding(new Insets(16, 20, 12, 20));
        topContainer.getChildren().addAll(createHeaderBar(primaryStage), createMetricsBar(), createFilterToolbar(primaryStage));
        root.setTop(topContainer);

        // 2. Central TableView
        tableView = createInventoryTableView();
        VBox tableContainer = new VBox(tableView);
        tableContainer.setPadding(new Insets(0, 20, 16, 20));
        VBox.setVgrow(tableView, Priority.ALWAYS);
        root.setCenter(tableContainer);

        // 3. Bottom Status Bar
        HBox statusBar = createStatusBar();
        root.setBottom(statusBar);

        // Load data from JDBC
        loadInventoryData();

        Scene scene = new Scene(root, 1200, 760);
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1000);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }

    private HBox createHeaderBar(Stage owner) {
        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("StockMaster Java");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #ffffff;");

        Label subtitle = new Label("· Relational JDBC Inventory Management Station");
        subtitle.setStyle("-fx-font-size: 13px; -fx-text-fill: #94a3b8;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRefresh = new Button("Refresh DB");
        btnRefresh.setStyle("-fx-background-color: #1e293b; -fx-text-fill: #e2e8f0; -fx-font-size: 12px; -fx-padding: 6 14; -fx-background-radius: 6; -fx-cursor: hand;");
        btnRefresh.setOnAction(e -> loadInventoryData());

        Button btnAuditLogs = new Button("View Audit Ledger");
        btnAuditLogs.setStyle("-fx-background-color: #1e293b; -fx-text-fill: #e2e8f0; -fx-font-size: 12px; -fx-padding: 6 14; -fx-background-radius: 6; -fx-cursor: hand;");
        btnAuditLogs.setOnAction(e -> openAuditLogDialog(owner));

        Button btnAddItem = new Button("+ Add New Item");
        btnAddItem.setStyle("-fx-background-color: #2563eb; -fx-text-fill: #ffffff; -fx-font-weight: bold; -fx-font-size: 12px; -fx-padding: 6 16; -fx-background-radius: 6; -fx-cursor: hand;");
        btnAddItem.setOnAction(e -> openItemDialog(owner, null));

        header.getChildren().addAll(title, subtitle, spacer, btnRefresh, btnAuditLogs, btnAddItem);
        return header;
    }

    private HBox createMetricsBar() {
        HBox bar = new HBox(24);
        bar.setPadding(new Insets(12, 16, 12, 16));
        bar.setStyle("-fx-background-color: #131c31; -fx-background-radius: 8; -fx-border-color: #1e293b; -fx-border-radius: 8;");
        bar.setAlignment(Pos.CENTER_LEFT);

        totalItemsLabel = createMetricCell("TOTAL ITEMS (SKUs)", "0", "#38bdf8");
        totalAssetValLabel = createMetricCell("TOTAL ASSET VALUE", "$0.00", "#10b981");
        lowStockCountLabel = createMetricCell("LOW STOCK ALERTS", "0", "#f59e0b");
        outOfStockLabel = createMetricCell("OUT OF STOCK", "0", "#ef4444");

        bar.getChildren().addAll(
            totalItemsLabel.getParent(),
            createDivider(),
            totalAssetValLabel.getParent(),
            createDivider(),
            lowStockCountLabel.getParent(),
            createDivider(),
            outOfStockLabel.getParent()
        );
        return bar;
    }

    private Label createMetricCell(String caption, String initialValue, String valColor) {
        VBox box = new VBox(3);
        Label cap = new Label(caption);
        cap.setStyle("-fx-font-size: 11px; -fx-text-fill: #64748b; -fx-font-weight: bold;");

        Label val = new Label(initialValue);
        val.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + valColor + "; -fx-font-family: 'JetBrains Mono', monospace;");

        box.getChildren().addAll(cap, val);
        return val;
    }

    private Region createDivider() {
        Region r = new Region();
        r.setPrefWidth(1);
        r.setMaxHeight(32);
        r.setStyle("-fx-background-color: #1e293b;");
        return r;
    }

    private HBox createFilterToolbar(Stage owner) {
        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        searchField = new TextField();
        searchField.setPromptText("Search by SKU, item name, or location bin...");
        searchField.setPrefWidth(320);
        searchField.setStyle("-fx-background-color: #1e293b; -fx-text-fill: #ffffff; -fx-prompt-text-fill: #64748b; -fx-background-radius: 6; -fx-padding: 7 12;");
        searchField.textProperty().addListener((obs, oldVal, newVal) -> applyFilters());

        categoryComboBox = new ComboBox<>();
        categoryComboBox.getItems().addAll("All Categories", "Electronics & Microcontrollers", "Industrial Tools & Hardware", "Raw Metals & Alloys", "Packaging & Dispatch", "Workplace Safety Equipment", "Lubricants & Solvents");
        categoryComboBox.setValue("All Categories");
        categoryComboBox.setStyle("-fx-background-color: #1e293b; -fx-text-fill: #e2e8f0; -fx-background-radius: 6;");
        categoryComboBox.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters());

        lowStockOnlyCheckBox = new CheckBox("Low Stock Reorder Required Only");
        lowStockOnlyCheckBox.setStyle("-fx-text-fill: #f59e0b; -fx-font-size: 12px;");
        lowStockOnlyCheckBox.selectedProperty().addListener((obs, oldVal, newVal) -> applyFilters());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button btnRestockAll = new Button("Quick Reorder Low Stock");
        btnRestockAll.setStyle("-fx-background-color: #d97706; -fx-text-fill: #ffffff; -fx-font-size: 12px; -fx-padding: 6 12; -fx-background-radius: 6; -fx-cursor: hand;");
        btnRestockAll.setOnAction(e -> handleBatchRestock());

        toolbar.getChildren().addAll(searchField, categoryComboBox, lowStockOnlyCheckBox, spacer, btnRestockAll);
        return toolbar;
    }

    private TableView<Item> createInventoryTableView() {
        TableView<Item> table = new TableView<>();
        table.setStyle("-fx-background-color: #111827; -fx-text-fill: #f3f4f6; -fx-border-color: #1f2937; -fx-border-radius: 6;");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Item, String> colSku = new TableColumn<>("SKU / Barcode");
        colSku.setCellValueFactory(new PropertyValueFactory<>("sku"));
        colSku.setPrefWidth(120);

        TableColumn<Item, String> colName = new TableColumn<>("Item Name");
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colName.setPrefWidth(220);

        TableColumn<Item, String> colCat = new TableColumn<>("Category");
        colCat.setCellValueFactory(new PropertyValueFactory<>("category"));
        colCat.setPrefWidth(180);

        TableColumn<Item, String> colBin = new TableColumn<>("Location Bin");
        colBin.setCellValueFactory(new PropertyValueFactory<>("locationBin"));
        colBin.setPrefWidth(90);

        TableColumn<Item, Integer> colQty = new TableColumn<>("In Stock");
        colQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        colQty.setPrefWidth(80);

        TableColumn<Item, Integer> colMin = new TableColumn<>("Min Reorder");
        colMin.setCellValueFactory(new PropertyValueFactory<>("minStock"));
        colMin.setPrefWidth(85);

        TableColumn<Item, String> colCost = new TableColumn<>("Unit Cost");
        colCost.setCellValueFactory(cell -> new SimpleStringProperty(currencyFormatter.format(cell.getValue().getCostPrice())));
        colCost.setPrefWidth(90);

        TableColumn<Item, String> colPrice = new TableColumn<>("Selling Price");
        colPrice.setCellValueFactory(cell -> new SimpleStringProperty(currencyFormatter.format(cell.getValue().getSellingPrice())));
        colPrice.setPrefWidth(90);

        TableColumn<Item, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colStatus.setPrefWidth(110);
        colStatus.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);
                if (empty || status == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(status.replace('_', ' '));
                    if ("OUT_OF_STOCK".equals(status)) {
                        setStyle("-fx-text-fill: #ef4444; -fx-font-weight: bold;");
                    } else if ("LOW_STOCK".equals(status)) {
                        setStyle("-fx-text-fill: #f59e0b; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #10b981;");
                    }
                }
            }
        });

        TableColumn<Item, Void> colActions = new TableColumn<>("Actions");
        colActions.setPrefWidth(180);
        colActions.setCellFactory(col -> new TableCell<>() {
            private final Button btnIn = new Button("+ Stock In");
            private final Button btnOut = new Button("- Stock Out");
            private final Button btnEdit = new Button("Edit");
            private final HBox pane = new HBox(6, btnIn, btnOut, btnEdit);

            {
                btnIn.setStyle("-fx-background-color: #065f46; -fx-text-fill: #34d399; -fx-font-size: 11px; -fx-padding: 3 8; -fx-background-radius: 4; -fx-cursor: hand;");
                btnOut.setStyle("-fx-background-color: #7f1d1d; -fx-text-fill: #f87171; -fx-font-size: 11px; -fx-padding: 3 8; -fx-background-radius: 4; -fx-cursor: hand;");
                btnEdit.setStyle("-fx-background-color: #1e293b; -fx-text-fill: #cbd5e1; -fx-font-size: 11px; -fx-padding: 3 8; -fx-background-radius: 4; -fx-cursor: hand;");

                btnIn.setOnAction(e -> {
                    Item item = getTableView().getItems().get(getIndex());
                    openStockMovementDialog((Stage) getTableView().getScene().getWindow(), item, "STOCK_IN");
                });
                btnOut.setOnAction(e -> {
                    Item item = getTableView().getItems().get(getIndex());
                    openStockMovementDialog((Stage) getTableView().getScene().getWindow(), item, "STOCK_OUT");
                });
                btnEdit.setOnAction(e -> {
                    Item item = getTableView().getItems().get(getIndex());
                    openItemDialog((Stage) getTableView().getScene().getWindow(), item);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : pane);
            }
        });

        table.getColumns().addAll(colSku, colName, colCat, colBin, colQty, colMin, colCost, colPrice, colStatus, colActions);
        return table;
    }

    private HBox createStatusBar() {
        HBox status = new HBox(16);
        status.setPadding(new Insets(8, 20, 8, 20));
        status.setAlignment(Pos.CENTER_LEFT);
        status.setStyle("-fx-background-color: #0f172a; -fx-border-color: #1e293b; -fx-border-width: 1 0 0 0;");

        Label dbIndicator = new Label("● JDBC: Connected (SQLite / HikariCP Pool Active)");
        dbIndicator.setStyle("-fx-text-fill: #10b981; -fx-font-size: 11px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label copyLabel = new Label("StockMaster Java v2.4 · Ready");
        copyLabel.setStyle("-fx-text-fill: #64748b; -fx-font-size: 11px;");

        status.getChildren().addAll(dbIndicator, spacer, copyLabel);
        return status;
    }

    public void loadInventoryData() {
        try {
            masterInventoryData.clear();
            masterInventoryData.addAll(itemDAO.getAllItems());

            filteredData = new FilteredList<>(masterInventoryData, p -> true);
            tableView.setItems(filteredData);
            updateDashboardMetrics();
        } catch (SQLException e) {
            showError("Database Error", "Failed to load inventory records: " + e.getMessage());
        }
    }

    private void applyFilters() {
        if (filteredData == null) return;
        String search = searchField.getText() == null ? "" : searchField.getText().trim().toLowerCase();
        String cat = categoryComboBox.getValue();
        boolean lowStockOnly = lowStockOnlyCheckBox.isSelected();

        filteredData.setPredicate(item -> {
            boolean matchesSearch = search.isEmpty() ||
                item.getSku().toLowerCase().contains(search) ||
                item.getName().toLowerCase().contains(search) ||
                item.getLocationBin().toLowerCase().contains(search);

            boolean matchesCat = cat == null || "All Categories".equals(cat) || item.getCategory().equalsIgnoreCase(cat);

            boolean matchesLowStock = !lowStockOnly || item.getQuantity() <= item.getMinStock();

            return matchesSearch && matchesCat && matchesLowStock;
        });
    }

    private void updateDashboardMetrics() {
        int total = masterInventoryData.size();
        double totalVal = masterInventoryData.stream().mapToDouble(i -> i.getQuantity() * i.getCostPrice()).sum();
        long lowCount = masterInventoryData.stream().filter(i -> i.getQuantity() <= i.getMinStock() && i.getQuantity() > 0).count();
        long outCount = masterInventoryData.stream().filter(i -> i.getQuantity() == 0).count();

        totalItemsLabel.setText(String.valueOf(total));
        totalAssetValLabel.setText(currencyFormatter.format(totalVal));
        lowStockCountLabel.setText(String.valueOf(lowCount));
        outOfStockLabel.setText(String.valueOf(outCount));
    }

    private void handleBatchRestock() {
        var lowStock = masterInventoryData.stream().filter(i -> i.getQuantity() <= i.getMinStock()).toList();
        if (lowStock.isEmpty()) {
            showInfo("Stock Master", "All inventory items are currently above minimum threshold. No reorders needed.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Batch Reorder");
        confirm.setHeaderText("Reorder " + lowStock.size() + " Low/Out-of-Stock Items?");
        confirm.setContentText("This will generate purchase orders and restock all depleted items back to their maximum capacity.");

        Optional<ButtonType> res = confirm.showAndWait();
        if (res.isPresent() && res.get() == ButtonType.OK) {
            try {
                for (Item itm : lowStock) {
                    int restockQty = Math.max(20, itm.getMaxStock() - itm.getQuantity());
                    itemDAO.updateStockQuantity(itm.getId(), itm.getQuantity() + restockQty);
                    transactionDAO.recordTransaction(new StockTransaction(
                        0, itm.getId(), itm.getSku(), itm.getName(), "STOCK_IN", restockQty,
                        itm.getCostPrice(), restockQty * itm.getCostPrice(), "PO-BATCH-" + System.currentTimeMillis() % 10000,
                        "Automatic replenishment batch order", "sys_procurement"
                    ));
                }
                loadInventoryData();
                showInfo("Restock Complete", "Successfully replenished " + lowStock.size() + " items.");
            } catch (SQLException e) {
                showError("Restock Failed", e.getMessage());
            }
        }
    }

    private void openItemDialog(Stage owner, Item existingItem) {
        // Implementation of modal add/edit item form
        Dialog<Item> dialog = new Dialog<>();
        dialog.initOwner(owner);
        dialog.setTitle(existingItem == null ? "Add New Inventory Item" : "Edit Item: " + existingItem.getSku());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField skuFld = new TextField(existingItem != null ? existingItem.getSku() : "SKU-" + System.currentTimeMillis() % 100000);
        TextField nameFld = new TextField(existingItem != null ? existingItem.getName() : "");
        TextField catFld = new TextField(existingItem != null ? existingItem.getCategory() : "Electronics & Microcontrollers");
        TextField binFld = new TextField(existingItem != null ? existingItem.getLocationBin() : "A-01-01");
        TextField qtyFld = new TextField(existingItem != null ? String.valueOf(existingItem.getQuantity()) : "10");
        TextField minFld = new TextField(existingItem != null ? String.valueOf(existingItem.getMinStock()) : "5");
        TextField maxFld = new TextField(existingItem != null ? String.valueOf(existingItem.getMaxStock()) : "100");
        TextField costFld = new TextField(existingItem != null ? String.valueOf(existingItem.getCostPrice()) : "15.00");
        TextField priceFld = new TextField(existingItem != null ? String.valueOf(existingItem.getSellingPrice()) : "25.00");

        grid.addRow(0, new Label("SKU:"), skuFld);
        grid.addRow(1, new Label("Name:"), nameFld);
        grid.addRow(2, new Label("Category:"), catFld);
        grid.addRow(3, new Label("Bin Location:"), binFld);
        grid.addRow(4, new Label("Initial Stock:"), qtyFld);
        grid.addRow(5, new Label("Min Threshold:"), minFld);
        grid.addRow(6, new Label("Max Capacity:"), maxFld);
        grid.addRow(7, new Label("Cost Price ($):"), costFld);
        grid.addRow(8, new Label("Selling Price ($):"), priceFld);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                try {
                    Item itm = existingItem != null ? existingItem : new Item();
                    itm.setSku(skuFld.getText().trim());
                    itm.setName(nameFld.getText().trim());
                    itm.setCategory(catFld.getText().trim());
                    itm.setLocationBin(binFld.getText().trim());
                    itm.setQuantity(Integer.parseInt(qtyFld.getText().trim()));
                    itm.setMinStock(Integer.parseInt(minFld.getText().trim()));
                    itm.setMaxStock(Integer.parseInt(maxFld.getText().trim()));
                    itm.setCostPrice(Double.parseDouble(costFld.getText().trim()));
                    itm.setSellingPrice(Double.parseDouble(priceFld.getText().trim()));
                    itm.setUnit("pcs");
                    itm.setSupplierId(1);
                    return itm;
                } catch (Exception ex) {
                    showError("Invalid input", ex.getMessage());
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(item -> {
            try {
                if (existingItem == null) {
                    itemDAO.addItem(item);
                } else {
                    itemDAO.updateItem(item);
                }
                loadInventoryData();
            } catch (SQLException ex) {
                showError("Save Failed", ex.getMessage());
            }
        });
    }

    private void openStockMovementDialog(Stage owner, Item item, String movementType) {
        TextInputDialog dialog = new TextInputDialog("10");
        dialog.initOwner(owner);
        dialog.setTitle(movementType.equals("STOCK_IN") ? "Stock In / Receipt" : "Stock Out / Dispatch");
        dialog.setHeaderText("Item: " + item.getName() + " (SKU: " + item.getSku() + ")\nCurrent Stock: " + item.getQuantity());
        dialog.setContentText("Enter quantity to " + (movementType.equals("STOCK_IN") ? "receive:" : "dispatch:"));

        dialog.showAndWait().ifPresent(strQty -> {
            try {
                int qty = Integer.parseInt(strQty.trim());
                if (qty <= 0) throw new IllegalArgumentException("Quantity must be positive");

                int newQty;
                if (movementType.equals("STOCK_IN")) {
                    newQty = item.getQuantity() + qty;
                } else {
                    if (item.getQuantity() < qty) {
                        showError("Insufficient Stock", "Cannot dispatch " + qty + ". Only " + item.getQuantity() + " available.");
                        return;
                    }
                    newQty = item.getQuantity() - qty;
                }

                itemDAO.updateStockQuantity(item.getId(), newQty);
                transactionDAO.recordTransaction(new StockTransaction(
                    0, item.getId(), item.getSku(), item.getName(), movementType,
                    movementType.equals("STOCK_IN") ? qty : -qty,
                    item.getCostPrice(), qty * item.getCostPrice(),
                    (movementType.equals("STOCK_IN") ? "PO-" : "SO-") + System.currentTimeMillis() % 10000,
                    "Manual UI " + movementType.toLowerCase(), "operator"
                ));
                loadInventoryData();
            } catch (Exception ex) {
                showError("Operation Failed", ex.getMessage());
            }
        });
    }

    private void openAuditLogDialog(Stage owner) {
        Stage stage = new Stage();
        stage.initOwner(owner);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Stock Movement Audit Ledger");

        TableView<StockTransaction> logTable = new TableView<>();
        logTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<StockTransaction, String> cTime = new TableColumn<>("Timestamp");
        cTime.setCellValueFactory(new PropertyValueFactory<>("timestamp"));

        TableColumn<StockTransaction, String> cSku = new TableColumn<>("SKU");
        cSku.setCellValueFactory(new PropertyValueFactory<>("itemSku"));

        TableColumn<StockTransaction, String> cType = new TableColumn<>("Type");
        cType.setCellValueFactory(new PropertyValueFactory<>("type"));

        TableColumn<StockTransaction, Integer> cQty = new TableColumn<>("Qty Delta");
        cQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        TableColumn<StockTransaction, String> cRef = new TableColumn<>("Ref No");
        cRef.setCellValueFactory(new PropertyValueFactory<>("referenceNo"));

        TableColumn<StockTransaction, String> cReason = new TableColumn<>("Notes / Reason");
        cReason.setCellValueFactory(new PropertyValueFactory<>("reason"));

        logTable.getColumns().addAll(cTime, cSku, cType, cQty, cRef, cReason);

        try {
            logTable.setItems(FXCollections.observableArrayList(transactionDAO.getAllTransactions()));
        } catch (SQLException e) {
            showError("Error", e.getMessage());
        }

        VBox layout = new VBox(10, logTable);
        layout.setPadding(new Insets(16));
        Scene scene = new Scene(layout, 800, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
